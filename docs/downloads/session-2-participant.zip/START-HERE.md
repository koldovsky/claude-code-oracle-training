# Сесія 2 · почніть тут

Розпакуйте весь архів зі збереженням структури тек. Наведені перші команди
виконуйте з теки, де лежить цей START-HERE.md.

Відкрийте [START-HERE.html](START-HERE.html) або
[центр матеріалів](tools/session-2.html) у браузері: звідти можна перейти
до слайдів, демо, шпаргалки та двогодинного відеоуроку онлайн.

Це матеріали того самого
[репозиторію курсу](https://github.com/koldovsky/oracle-claude-training-materials),
що й у Сесії 1. Якщо ви розпакували цей ZIP, додатково клонувати репозиторій
не потрібно. Корінь комплекту — тека з цим START-HERE.md і каталогом training/.

## Матеріали

- [Робочий листок](training/HANDOUT-SESSION-2.md)
- [Домашнє завдання №2](training/HOMEWORK-SESSION-2.md)
- [Інструкція лабораторії](training/session-2/README.md)
- [Контракт пакета](training/session-2/lab/SPEC.md)
- [Шпаргалка з командами](tools/cheatsheet-session-2.html)
- [Записи демонстрацій](tools/session-2-rehearsal.html)
- [Слайди PDF](slides/session-2.pdf)
- [Слайди з навігацією](tools/session-2-slides.html)
- [Відеоурок · 2 години · онлайн](https://koldovsky.github.io/claude-code-oracle-training/session-2-video.html)

Записи містять розбір і виправлення пакета. Відкривайте відповідний фрагмент
після власної спроби виконати вправу. Програвач працює офлайн.

## Підготовка

Потрібні Python 3.10+, Git, SQLcl, Claude Code та ваше збережене підключення
SQLcl train із Сесії 1. Доступ до навчальної Oracle надає тренер окремо.
Якщо Python у вашій системі запускається як python3, використовуйте цю назву.

    python training/session-2/check-environment.py
    python training/session-2/check-environment.py --database
    python training/session-2/setup-workspace.py
    cd training/session-2/workspace

Очікуємо PREFLIGHT_PASS та WORKSPACE_READY. Підготовка створює окремий Git-проєкт
із початковим комітом. Якщо робоча тека вже існує, вона не перезаписується.

## Початок заняття

Наступні команди виконуйте з підготовленої робочої теки:

    sql -S -name train @lab/install.sql
    sql -S -name train @lab/verify-baseline.sql
    claude

Кожен SQL-скрипт завершує свій процес SQLcl. Використовуйте окремі навчальні
підключення без іншої незавершеної транзакції.

BASELINE_CONFIRMED підтверджує початковий пакет із п'ятьма відомими дефектами.
Після виправлення lab/settlement.pkb.sql:

    sql -S -name train @lab/compile.sql
    sql -S -name train @lab/verify.sql

Очікуємо COMPILE_OK та ACCEPTANCE_PASS: усі 18 перевірок пройдено.
Специфікацію, перевірки й settlement-starter.pkb.sql залишаємо незміненими.
Повернення до початку та очищення описані в інструкції лабораторії.

## Необов'язково: запуск через Python

Для автоматизованого термінала або запуску з перевіркою результату можна
використати run-lab.py. З теки START-HERE.md:

    python training/session-2/run-lab.py compile
    python training/session-2/run-lab.py verify

За замовчуванням він використовує підготовлену теку training/session-2/workspace
та з'єднання train. Для іншої теки або з'єднання:

    python training/session-2/run-lab.py verify --workspace "шлях/до/робочої теки" --connection train

Очікуємо SQLCL_RUN_PASS. Скрипт перевіряє код завершення SQLcl, повідомлення
про помилки та підсумкову позначку обраної дії. Доступні дії install, baseline,
compile, verify, reset і cleanup; вибирайте лише потрібну дію.

Для локальної перевірки інструментів архіву, з теки START-HERE.md:

    python -m unittest discover -s training/session-2/tests -v

Ці Python-тести не підключаються до бази даних.
